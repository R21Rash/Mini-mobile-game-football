package com.example.football


import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var playButton: ImageView
    private lateinit var loadingProgressBar: ProgressBar
    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playButton = findViewById(R.id.backgroundImageView)
        loadingProgressBar = findViewById(R.id.loadingProgressBar)

        // Initialize MediaPlayer with the gamesong.mp3
        mediaPlayer = MediaPlayer.create(this, R.raw.gamesong)
        mediaPlayer.isLooping = true // Loop the music

        playButton.setOnClickListener {
            // Show loading indicator
            loadingProgressBar.visibility = View.VISIBLE

            // Simulate some loading process (Replace with your actual loading logic)
            simulateLoading()
        }
    }
    // Simulate loading process
    private fun simulateLoading() {
        // You can replace this with your actual loading logic.
        // For example, making a network request, loading data from a database, etc.
        // Here, we're just delaying for demonstration purposes.
        val loadingProgressBar = findViewById<ProgressBar>(R.id.loadingProgressBar)
        loadingProgressBar.visibility = View.VISIBLE // Show the progress bar

        Thread {
            try {
                for (progress in 0..100 step 25) { // Increment progress in steps of 25
                    Thread.sleep(1000) // Simulate a 1-second loading step
                    runOnUiThread {
                        loadingProgressBar.progress = progress // Set the progress
                    }
                }
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }

            // Hide loading indicator after loading is complete
            runOnUiThread {
                loadingProgressBar.visibility = View.GONE
                // Start LaunchPage1 activity
                startActivity(Intent(this, LaunchPage1::class.java))
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        // Start playing the music when MainActivity resumes
        mediaPlayer.start()
    }

    override fun onPause() {
        super.onPause()
        // Pause the music when MainActivity is paused
        mediaPlayer.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release the MediaPlayer resources when MainActivity is destroyed
        mediaPlayer.release()
    }
}
